package com.demo.fnc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FncApplication {

	public static void main(String[] args) {
		SpringApplication.run(FncApplication.class, args);
	}

}
