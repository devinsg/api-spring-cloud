package com.demo.fnc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FncApplicationTests {

	@Test
	void contextLoads() {
	}

}
